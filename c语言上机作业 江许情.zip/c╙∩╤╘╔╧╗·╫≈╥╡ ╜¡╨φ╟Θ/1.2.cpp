#include <stdio.h>
int main()
{
	
printf("\"How many student here?\"\n");
printf("\"500\"\n");
return 0;
} 